
## Project setup
```
npm install
```

### Run
```
npm start
```

### port
```
Server is running on port 8000
```


##   import this in src/external  in react frontend

## Enter URL =  Only From (www to .com/.in/etc...) Example : www.xyz.com   OR
## enter IP =  only IP Like  '28.125.85.83'   OR
## Enter LocalHost = form local site