// const sql = require("./db.js");
// Requiring fs module
const fs = require("fs");
var data = fs.readFileSync("./data.json");
// constructor
const Testing = function (testing) {
  this.title = testing.title;
  this.description = testing.description;
  this.published = testing.published;
};

Testing.create = (newtesting, result) => {
  var myObject = JSON.parse(data);
  var id_length = myObject.length +1
  // Defining new data to be added
  newtesting['id'] = id_length
  newtesting['currrency'] = '$'+newtesting['currrency'] 
  let newData = newtesting

  // Adding the new data to our object
  myObject.push(newData);

  // Writing to our JSON file
  var newData2 = JSON.stringify(myObject);
  fs.writeFile("data.json", newData2, (err) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created testing: ", { id: id_length });
    result(null, { id: id_length });
  });
};

Testing.findById = (id, result) => {
  sql.query(`SELECT * FROM testings WHERE id = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found testing: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found testing with the id
    result({ kind: "not_found" }, null);
  });
};

Testing.getAll = (title, result) => {
  var myObject = JSON.parse(data);
  console.log("testings: ", myObject.length);
  result(null, myObject);
};


module.exports = Testing;
