module.exports = app => {
  const testings = require("../controllers/testing.controller.js");

  var router = require("express").Router();

  router.get("/", (req, res) => {
    res.json({ message: "Welcome to bezkoder application." });
  });
  // Create a new testing
  router.post("/create_from/", testings.create);

  // Retrieve all testings
  router.get("/get_all/", testings.findAll);

  // Retrieve a single testing with id
  router.get("/get_one/:id", testings.findOne);

  app.use('/api/testings', router);
};
