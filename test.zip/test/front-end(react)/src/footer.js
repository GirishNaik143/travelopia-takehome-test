import React from "react";

const FooterPage = () => {
    return (
        <div className="footer">
            <p>Footer</p>
        </div>
    );
}

export default FooterPage;