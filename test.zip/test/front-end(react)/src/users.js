import React, { useState, useEffect } from 'react';
const loader = document.querySelector('.loader');

const external_ip = require('./external.js')

function TableData() {
    const [data, getData] = useState([])
    const URL = `http://${external_ip.IP}:8000/api/testings/get_all`;

    const showLoader = () => loader.classList.remove('loader--hide');
    const hideLoader = () => loader.classList.add('loader--hide');
    useEffect(() => {
        fetchData()
    }, [])


    const fetchData = () => {
        fetch(URL)
            .then((res) =>
                res.json())

            .then((response) => {
                console.log(response);
                getData(response);
                hideLoader()
            })

    }

    return (
        <>
            <h1>Displaying List Of Users</h1>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email address</th>
                        <th>Where do you want to go?</th>
                        <th>No. of travellers</th>
                        <th>Currency</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item, i) => (
                        <tr key={i}>
                            <td>{item.name}</td>
                            <td>{item.email}</td>
                            <td>{item.destination}</td>
                            <td>{item.no_of_passanger}</td>
                            <td>{item.currency}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    );
}

export default TableData;