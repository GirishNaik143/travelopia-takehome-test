import "./App.css";
import "./Appcss.scss";
import React, { useState, useEffect } from 'react';
const loader = document.querySelector('.loader');

const external_ip = require('./external.js')

function App() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [destination, setDestination] = useState("");
    const [currency, setCurrency] = useState("");
    const [no_of_passanger, setno_of_passanger] = useState("");
    const [message, setMessage] = useState("");
    const [myData, setMyData] = useState([]);

    const showLoader = () => loader.classList.remove('loader--hide');
    const hideLoader = () => loader.classList.add('loader--hide');
    // setCurrency('select')
    useEffect(() => {
        // fetch('https://trial.mobiscroll.com/content/countries.json')
        //     .then((res) =>
        //         res.json())

        //     .then((response) => {
        //         console.log(response);
        //         setMyData(response);
                hideLoader();
        //     })
    }, []);
    let handleSubmit = async (e) => {
        e.preventDefault();
        try {
            let res = await fetch(`http://${external_ip.IP}:8000/api/testings/create_from`, {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: name,
                    email: email,
                    destination: destination,
                    currency: currency,
                    no_of_passanger: no_of_passanger,
                }),
            });
            let resJson = await res.json();
            if (res.status === 200) {
                setName("");
                setEmail("");
                setDestination("");
                setCurrency("");
                setno_of_passanger("");
                setMessage("User created successfully");
            } else {
                setMessage("Some error occured");
            }
        } catch (err) {
            console.log(err);
        }
    };

    return (
        <div className="">
            <form onSubmit={handleSubmit} className="login-form">
                <div className="form-input-material">
                    <input
                        name="Name"
                        required
                        autoComplete="off"
                        className="form-control-material"
                        type="text"
                        value={name}
                        placeholder=""
                        onChange={(e) => setName(e.target.value)}
                    />
                    <label htmlFor="Name">Name</label>
                </div>
                <div className="form-input-material">
                    <input
                        name="Email"
                        required
                        autoComplete="off"
                        className="form-control-material"
                        type="text"
                        value={email}
                        placeholder=""
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <label htmlFor="Email">Email</label>
                </div>
                <div className="form-input-material">
                    <select
                        name="Country"
                        value={currency}
                        onChange={(e) => setCurrency(e.target.value)}
                        className="form-control-material"
                    >
                        <option value="select">Select an Country</option>
                        {myData.map((option, i) => (
                            <option value={option.text} key={option.text} >{option.text}</option>
                        ))}
                        {/* {myData.map(option => {
                            return <option value={option.text} key={option.text} >{option.text}</option>
                        })} */}
                    </select>
                    <label htmlFor="Country">Country</label>
                </div>
                <div className="form-input-material">
                    <input
                        name="nooftraveller"
                        required
                        autoComplete="off"
                        className="form-control-material"
                        type="number"
                        value={no_of_passanger}
                        placeholder=""
                        onChange={(e) => setno_of_passanger(e.target.value)}
                    />
                    <label htmlFor="nooftraveller">No. of Travellers</label>
                </div>
                <div className="form-input-material">
                    <input
                        name="Currency"
                        required
                        autoComplete="off"
                        className="form-control-material"
                        type="text"
                        value={currency}
                        placeholder=""
                        onChange={(e) => setCurrency(e.target.value)}
                    />
                    <label htmlFor="Currency">Currency</label>
                </div>

                <button type="submit" className="btn btn-primary btn-ghost">Submit</button>
                <div className="message">{message ? <p>{message}</p> : null}</div>
            </form>
        </div>
    );
}

export default App;
