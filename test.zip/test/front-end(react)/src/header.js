import React from "react";
import { NavLink } from "react-router-dom";
function Header() {
    return (
            <nav>
                <NavLink activeclassname="active" to="/">        Home
      </NavLink>
                <NavLink activeclassname="active" to="/users">        Users
      </NavLink>
            </nav>
    );
}
export default Header;
